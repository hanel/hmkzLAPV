#ifndef BILANR_H_INCLUDED
#define BILANR_H_INCLUDED

#include <Rcpp.h>

#ifndef BIL_OSTREAM
#define BIL_OSTREAM Rcpp::Rcout
#endif

#include "bil_model.h"

#endif // BILANR_H_INCLUDED
