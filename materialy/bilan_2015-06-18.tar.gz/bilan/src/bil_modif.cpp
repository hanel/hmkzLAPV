#include "bil_modif.h"

using namespace std;

/**
 * - creates a model with given modifications
 * @param type daily or monthly time step version
 * @param modif_types result of bitwise OR for required modifications
 */
bilan_modif::bilan_modif(bilan_type type, unsigned modif_types) : bilan(type)
{
  modif_type = modif_types;
  period = 0;
  if (is_modif_type(PERIOD))
    throw bil_err("Model cannot be created because period length is not set.");
}

/**
 * - creates an empty model instance of given type and modification type Soc only
 * @param type daily or monthly time step version
 * @param modif_types result of bitwise OR for required modifications
 * @param period length of time step (in days) used instead of monthly or daily
 */
bilan_modif::bilan_modif(bilan_type type, unsigned modif_types, unsigned period) : bilan(type)
{
  modif_type = modif_types;
  this->period = period;
}

/**
 * - assignment operator
 */
bilan& bilan_modif::operator=(const bilan& orig)
{
  if (this != &orig) {
    bilan::operator=(orig);
    const bilan_modif& tmp_orig = dynamic_cast<const bilan_modif&>(orig);
    modif_type = tmp_orig.modif_type;
    period = tmp_orig.period;
  }
  return *this;
}

/**
 * - copy constructor
 */
bilan_modif::bilan_modif(const bilan_modif& orig) : bilan(orig)
{
  modif_type = orig.modif_type;
  period = orig.period;
}

/**
 * - increases given date according to model time step
 * @param tmp_date date whose value will be increased
 */
void bilan_modif::increase_calendar(date &tmp_date)
{
  if (is_modif_type(PERIOD)) {
    for (unsigned d = 0; d < period; d++)
     tmp_date.increase(date::DAY);
  }
  else
    bilan::increase_calendar(tmp_date);
}

/**
 * - gets begin and end for PET calculation
 * @param begin_doy begin of the interval
 * @param end_doy end of the interval
 */
void bilan_modif::get_doy_range(unsigned &begin_doy, unsigned &end_doy)
{
  if (is_modif_type(PERIOD)) {
    begin_doy = calen[ts].get_day_of_year();
    end_doy = begin_doy - 1 + period;
    //end_doy > days_in_year allowed because of periodic functions, only neglecting possible difference in number of days in years
  }
  else
    bilan::get_doy_range(begin_doy, end_doy);
}

/**
 * - recalculates values of PET from months to days (or keeps it for monthly time step)
 * - for vegetation zone method only since empirical tables contain monthly values
 */
void bilan_modif::recalc_pet_from_months()
{
  if (is_modif_type(PERIOD)) {
    for (ts = 0; ts < time_steps; ts++)
      var[ts][PET] = var[ts][PET] * period / 30;
  }
  else
    bilan::recalc_pet_from_months();
}

/**
 * - gets Soc or Socd parameter according to the model time step
 * @param mode model mode based on season
 * @return parameter value
 */
double bilan_modif::get_divide_coeff(int mode)
{
  if (is_modif_type(SOC_ONLY)) {
    int tmp_par;
    if (type == DAILY) {
        if (mode == ZIMNI)
          throw bil_err("No dividing coefficient for the given mode.");
        else
          tmp_par = Socd;
    }
    else
      tmp_par = Soc;
    return param[tmp_par].value;
  }
  else
    return bilan::get_divide_coeff(mode);
}

/**
 * - calculates optimization criterion for given variables
 * - NS and LNNS are residuals to 1 (to be minimized)
 * @param crit_type type of optimization criterion
 * @param weight_BF weight for baseflow
 * @param use_weights whether to use weights for time steps of runoff
 * @return value of the criterion
 */
long double bilan_modif::calc_crit_RM_BF(unsigned crit_type, double weight_BF, bool use_weights)
{
  if (is_modif_type(VAR_CRIT)) {
    if (crit_vars_vec.size() == 0)
      throw bil_err("No variables for criterion provided.");

    long double ok = 0;
    for (unsigned v = 0; v < crit_vars_vec.size(); v++) {
      ok = ok + crit_vars_vec[v].weight * calc_crit(crit_type, crit_vars_vec[v].var_obs, crit_vars_vec[v].var_mod, use_weights);
    }
    return ok;
  }
  else
    return bilan::calc_crit_RM_BF(crit_type, weight_BF, use_weights);
}

/**
 * - defines variables for optimization criterion
 * @param weights weights for variable pairs (does not need to sum up to 1)
 * @param vars_obs observed variables
 * @param vars_mod corresponding modelled variables
 */
void bilan_modif::set_var_crit(const vector<double> &weights, const vector<unsigned> &vars_obs, const vector<unsigned> &vars_mod)
{
  if (vars_obs.size() != vars_mod.size())
    throw bil_err("Number of observed and modelled variables for criterion differs.");
  if (weights.size() != vars_mod.size())
    throw bil_err("Number of weights and variables for criterion differs.");

  double weights_sum = 0;
  for (unsigned v = 0; v < weights.size(); v++) {
    weights_sum += weights[v];
  }
  crit_vars_vec.resize(weights.size());
  for (unsigned v = 0; v < weights.size(); v++) {
    crit_vars_vec[v].weight = weights[v] / weights_sum;
    crit_vars_vec[v].var_obs = vars_obs[v];
    crit_vars_vec[v].var_mod = vars_mod[v];
  }
}
